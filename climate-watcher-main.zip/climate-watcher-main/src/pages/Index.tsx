import { useState, useMemo } from "react";
import { Cloud, Thermometer, Droplets, TrendingUp, Calendar, Wind } from "lucide-react";
import { StatsCard } from "@/components/StatsCard";
import { TemperatureChart } from "@/components/TemperatureChart";
import { RainfallChart } from "@/components/RainfallChart";
import { MonthlyComparisonChart } from "@/components/MonthlyComparisonChart";
import { AQIChart } from "@/components/AQIChart";
import { AQIGauge } from "@/components/AQIGauge";
import { LocationSelector } from "@/components/LocationSelector";
import { generateSampleData, calculateMovingAverage, calculateStats } from "@/data/sampleClimateData";
import { indianLocations, Location } from "@/data/locationDatabase";

const Index = () => {
  const [selectedLocation, setSelectedLocation] = useState<Location>(indianLocations[0]);
  const climateData = useMemo(() => generateSampleData(selectedLocation), [selectedLocation]);
  const stats = useMemo(() => calculateStats(climateData), [climateData]);
  
  const temperatures = climateData.map(d => d.temperature);
  const tempMovingAvg = useMemo(() => calculateMovingAverage(temperatures, 12), [temperatures]);

  return (
    <div className="space-y-6">
      {/* Location Selector */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Climate Analysis</h2>
          <p className="text-muted-foreground">
            Examining temperature and rainfall patterns over time
          </p>
        </div>
        <LocationSelector selectedLocation={selectedLocation} onLocationChange={setSelectedLocation} />
      </div>
      {/* Location Hierarchy Breadcrumb */}
      <div className="bg-card rounded-lg p-4 border border-border">
        <div className="flex items-center gap-2 text-sm flex-wrap">
          <span className="text-muted-foreground">{selectedLocation.country}</span>
          <span className="text-muted-foreground">→</span>
          <span className="text-muted-foreground font-medium">{selectedLocation.region}</span>
          <span className="text-muted-foreground">→</span>
          <span className="text-foreground font-semibold">{selectedLocation.name}</span>
          <span className="ml-2 px-2 py-0.5 bg-secondary rounded-full text-xs text-muted-foreground">
            {selectedLocation.type}
          </span>
        </div>
      </div>

      {/* Introduction Section */}
      <div className="bg-card rounded-xl p-6 border border-border">
        <div className="flex items-start gap-3">
          <div className="flex-1">
            <h3 className="text-xl font-semibold mb-3 text-foreground">
              Climate Change Impact Analysis - {selectedLocation.name}
            </h3>
            <p className="text-muted-foreground leading-relaxed">
              This dashboard presents a comprehensive analysis of temperature and rainfall trends in{' '}
              <strong>{selectedLocation.name}</strong>, {selectedLocation.region}, {selectedLocation.country} over the past decade (2014-2024). 
              The data reveals significant climate patterns including rising temperatures and shifting precipitation patterns, 
              providing insights into the regional impact of climate change.
            </p>
          </div>
          <div className="hidden sm:block px-3 py-1.5 rounded-lg bg-secondary text-xs font-medium text-muted-foreground whitespace-nowrap">
            District Level
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <StatsCard
          title="Average Temperature"
          value={`${stats.avgTemp}°C`}
          description="2014-2024 Mean"
          icon={<Thermometer className="h-5 w-5" />}
          trend={stats.tempTrend}
          trendLabel="vs first 5 years"
        />
        <StatsCard
          title="Total Rainfall"
          value={`${stats.totalRainfall}mm`}
          description="Cumulative (10 years)"
          icon={<Droplets className="h-5 w-5" />}
        />
        <StatsCard
          title="Temperature Range"
          value={`${stats.minTemp}-${stats.maxTemp}°C`}
          description="Min to Max recorded"
          icon={<TrendingUp className="h-5 w-5" />}
        />
        <StatsCard
          title="Rainfall Trend"
          value={`${stats.rainTrend > 0 ? '+' : ''}${stats.rainTrend}%`}
          description="Last 5 vs First 5 years"
          icon={<Calendar className="h-5 w-5" />}
          trend={stats.rainTrend}
        />
        <StatsCard
          title="Average AQI"
          value={stats.avgAQI}
          description="10-year average"
          icon={<Wind className="h-5 w-5" />}
          trend={stats.aqiTrend}
          trendLabel="vs first 5 years"
          invertTrend={true}
        />
      </div>

      {/* AQI Live Status */}
      <AQIGauge currentAQI={stats.currentAQI} category={stats.currentAQICategory} />

      {/* Charts Section */}
      <TemperatureChart data={climateData} movingAverage={tempMovingAvg} />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <RainfallChart data={climateData} />
        <MonthlyComparisonChart data={climateData} />
      </div>

      {/* AQI Historical Analysis */}
      <AQIChart data={climateData} />

      {/* Key Findings */}
      <div className="bg-card rounded-xl p-6 border border-border">
        <h3 className="text-xl font-semibold mb-4 text-foreground">Key Findings</h3>
        <div className="space-y-3 text-muted-foreground">
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-2 h-2 rounded-full bg-temperature mt-2" />
            <p>
              <strong className="text-foreground">Rising Temperatures:</strong> Average temperature has increased by {stats.tempTrend}°C 
              over the past decade, indicating a clear warming trend consistent with global climate patterns.
            </p>
          </div>
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-2 h-2 rounded-full bg-rainfall mt-2" />
            <p>
              <strong className="text-foreground">Monsoon Variability:</strong> Rainfall patterns show {stats.rainTrend > 0 ? 'an increase' : 'a decrease'} 
              of {Math.abs(stats.rainTrend)}% in recent years, suggesting shifting monsoon dynamics.
            </p>
          </div>
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-2 h-2 rounded-full bg-accent mt-2" />
            <p>
              <strong className="text-foreground">Seasonal Shifts:</strong> The 12-month moving average reveals long-term trends 
              beyond seasonal variations, highlighting persistent climate change impacts.
            </p>
          </div>
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-2 h-2 rounded-full bg-chart-3 mt-2" />
            <p>
              <strong className="text-foreground">Air Quality Deterioration:</strong> AQI has worsened by {stats.aqiTrend} points 
              over the decade, with current levels at {stats.currentAQI} ({stats.currentAQICategory}). Winter months show significantly 
              higher pollution levels compared to monsoon season.
            </p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="text-center text-sm text-muted-foreground pt-4 border-t">
        <p>Data Source: Sample climate data based on NOAA patterns • Analysis Period: 2014-2024</p>
      </div>
    </div>
  );
};

export default Index;
