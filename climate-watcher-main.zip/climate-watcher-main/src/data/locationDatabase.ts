export interface Location {
  id: string;
  name: string;
  region: string; // State/Province/Country
  country: string;
  type: 'city' | 'town' | 'village' | 'district';
  baseTemp: number;
  monsoonMonths: number[];
  monsoonIntensity: number;
  latitude?: number;
  longitude?: number;
}

// Indian Locations - Organized by state
export const indianLocations: Location[] = [
  // Maharashtra
  { id: 'mumbai', name: 'Mumbai', region: 'Maharashtra', country: 'India', type: 'city', baseTemp: 28, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 400 },
  { id: 'pune', name: 'Pune', region: 'Maharashtra', country: 'India', type: 'city', baseTemp: 26, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 220 },
  { id: 'nagpur', name: 'Nagpur', region: 'Maharashtra', country: 'India', type: 'city', baseTemp: 27, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 200 },
  { id: 'nashik', name: 'Nashik', region: 'Maharashtra', country: 'India', type: 'city', baseTemp: 27, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 190 },
  { id: 'aurangabad', name: 'Aurangabad', region: 'Maharashtra', country: 'India', type: 'city', baseTemp: 27, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 180 },
  { id: 'mahabaleshwar', name: 'Mahabaleshwar', region: 'Maharashtra', country: 'India', type: 'town', baseTemp: 22, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 500 },
  
  // Delhi & NCR
  { id: 'delhi', name: 'Delhi', region: 'Delhi', country: 'India', type: 'city', baseTemp: 25, monsoonMonths: [7, 8, 9], monsoonIntensity: 200 },
  { id: 'gurgaon', name: 'Gurgaon', region: 'Haryana', country: 'India', type: 'city', baseTemp: 25, monsoonMonths: [7, 8, 9], monsoonIntensity: 190 },
  { id: 'noida', name: 'Noida', region: 'Uttar Pradesh', country: 'India', type: 'city', baseTemp: 25, monsoonMonths: [7, 8, 9], monsoonIntensity: 195 },
  
  // Karnataka
  { id: 'bangalore', name: 'Bangalore', region: 'Karnataka', country: 'India', type: 'city', baseTemp: 24, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 150 },
  { id: 'mysore', name: 'Mysore', region: 'Karnataka', country: 'India', type: 'city', baseTemp: 25, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 160 },
  { id: 'mangalore', name: 'Mangalore', region: 'Karnataka', country: 'India', type: 'city', baseTemp: 27, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 400 },
  { id: 'hubli', name: 'Hubli', region: 'Karnataka', country: 'India', type: 'city', baseTemp: 26, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 170 },
  { id: 'coorg', name: 'Coorg', region: 'Karnataka', country: 'India', type: 'district', baseTemp: 23, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 350 },
  
  // Tamil Nadu
  { id: 'chennai', name: 'Chennai', region: 'Tamil Nadu', country: 'India', type: 'city', baseTemp: 29, monsoonMonths: [10, 11, 12], monsoonIntensity: 300 },
  { id: 'coimbatore', name: 'Coimbatore', region: 'Tamil Nadu', country: 'India', type: 'city', baseTemp: 27, monsoonMonths: [10, 11], monsoonIntensity: 180 },
  { id: 'madurai', name: 'Madurai', region: 'Tamil Nadu', country: 'India', type: 'city', baseTemp: 29, monsoonMonths: [10, 11], monsoonIntensity: 200 },
  { id: 'ooty', name: 'Ooty', region: 'Tamil Nadu', country: 'India', type: 'town', baseTemp: 18, monsoonMonths: [10, 11], monsoonIntensity: 300 },
  { id: 'trichy', name: 'Tiruchirappalli', region: 'Tamil Nadu', country: 'India', type: 'city', baseTemp: 29, monsoonMonths: [10, 11], monsoonIntensity: 190 },
  
  // Kerala
  { id: 'kochi', name: 'Kochi', region: 'Kerala', country: 'India', type: 'city', baseTemp: 28, monsoonMonths: [6, 7, 8, 9, 10], monsoonIntensity: 350 },
  { id: 'thiruvananthapuram', name: 'Thiruvananthapuram', region: 'Kerala', country: 'India', type: 'city', baseTemp: 28, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 340 },
  { id: 'kozhikode', name: 'Kozhikode', region: 'Kerala', country: 'India', type: 'city', baseTemp: 28, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 360 },
  { id: 'munnar', name: 'Munnar', region: 'Kerala', country: 'India', type: 'town', baseTemp: 20, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 380 },
  { id: 'wayanad', name: 'Wayanad', region: 'Kerala', country: 'India', type: 'district', baseTemp: 23, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 400 },
  
  // West Bengal
  { id: 'kolkata', name: 'Kolkata', region: 'West Bengal', country: 'India', type: 'city', baseTemp: 27, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 320 },
  { id: 'darjeeling', name: 'Darjeeling', region: 'West Bengal', country: 'India', type: 'town', baseTemp: 16, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 450 },
  { id: 'siliguri', name: 'Siliguri', region: 'West Bengal', country: 'India', type: 'city', baseTemp: 25, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 380 },
  
  // Gujarat
  { id: 'ahmedabad', name: 'Ahmedabad', region: 'Gujarat', country: 'India', type: 'city', baseTemp: 28, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 160 },
  { id: 'surat', name: 'Surat', region: 'Gujarat', country: 'India', type: 'city', baseTemp: 28, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 280 },
  { id: 'vadodara', name: 'Vadodara', region: 'Gujarat', country: 'India', type: 'city', baseTemp: 27, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 180 },
  { id: 'rajkot', name: 'Rajkot', region: 'Gujarat', country: 'India', type: 'city', baseTemp: 28, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 140 },
  
  // Rajasthan
  { id: 'jaipur', name: 'Jaipur', region: 'Rajasthan', country: 'India', type: 'city', baseTemp: 27, monsoonMonths: [7, 8, 9], monsoonIntensity: 140 },
  { id: 'udaipur', name: 'Udaipur', region: 'Rajasthan', country: 'India', type: 'city', baseTemp: 26, monsoonMonths: [7, 8, 9], monsoonIntensity: 130 },
  { id: 'jodhpur', name: 'Jodhpur', region: 'Rajasthan', country: 'India', type: 'city', baseTemp: 28, monsoonMonths: [7, 8], monsoonIntensity: 100 },
  { id: 'jaisalmer', name: 'Jaisalmer', region: 'Rajasthan', country: 'India', type: 'city', baseTemp: 29, monsoonMonths: [7, 8], monsoonIntensity: 80 },
  
  // Uttar Pradesh
  { id: 'lucknow', name: 'Lucknow', region: 'Uttar Pradesh', country: 'India', type: 'city', baseTemp: 26, monsoonMonths: [7, 8, 9], monsoonIntensity: 200 },
  { id: 'kanpur', name: 'Kanpur', region: 'Uttar Pradesh', country: 'India', type: 'city', baseTemp: 26, monsoonMonths: [7, 8, 9], monsoonIntensity: 190 },
  { id: 'varanasi', name: 'Varanasi', region: 'Uttar Pradesh', country: 'India', type: 'city', baseTemp: 27, monsoonMonths: [7, 8, 9], monsoonIntensity: 210 },
  { id: 'agra', name: 'Agra', region: 'Uttar Pradesh', country: 'India', type: 'city', baseTemp: 26, monsoonMonths: [7, 8, 9], monsoonIntensity: 180 },
  
  // Madhya Pradesh
  { id: 'indore', name: 'Indore', region: 'Madhya Pradesh', country: 'India', type: 'city', baseTemp: 26, monsoonMonths: [7, 8, 9], monsoonIntensity: 180 },
  { id: 'bhopal', name: 'Bhopal', region: 'Madhya Pradesh', country: 'India', type: 'city', baseTemp: 26, monsoonMonths: [7, 8, 9], monsoonIntensity: 190 },
  { id: 'gwalior', name: 'Gwalior', region: 'Madhya Pradesh', country: 'India', type: 'city', baseTemp: 27, monsoonMonths: [7, 8, 9], monsoonIntensity: 170 },
  
  // Telangana & Andhra Pradesh
  { id: 'hyderabad', name: 'Hyderabad', region: 'Telangana', country: 'India', type: 'city', baseTemp: 27, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 180 },
  { id: 'visakhapatnam', name: 'Visakhapatnam', region: 'Andhra Pradesh', country: 'India', type: 'city', baseTemp: 28, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 220 },
  { id: 'vijayawada', name: 'Vijayawada', region: 'Andhra Pradesh', country: 'India', type: 'city', baseTemp: 28, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 200 },
  
  // Odisha
  { id: 'bhubaneswar', name: 'Bhubaneswar', region: 'Odisha', country: 'India', type: 'city', baseTemp: 28, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 300 },
  { id: 'puri', name: 'Puri', region: 'Odisha', country: 'India', type: 'town', baseTemp: 28, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 320 },
  
  // Punjab & Haryana
  { id: 'chandigarh', name: 'Chandigarh', region: 'Punjab/Haryana', country: 'India', type: 'city', baseTemp: 24, monsoonMonths: [7, 8, 9], monsoonIntensity: 150 },
  { id: 'amritsar', name: 'Amritsar', region: 'Punjab', country: 'India', type: 'city', baseTemp: 24, monsoonMonths: [7, 8, 9], monsoonIntensity: 160 },
  { id: 'ludhiana', name: 'Ludhiana', region: 'Punjab', country: 'India', type: 'city', baseTemp: 24, monsoonMonths: [7, 8, 9], monsoonIntensity: 155 },
  
  // Bihar & Jharkhand
  { id: 'patna', name: 'Patna', region: 'Bihar', country: 'India', type: 'city', baseTemp: 27, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 240 },
  { id: 'ranchi', name: 'Ranchi', region: 'Jharkhand', country: 'India', type: 'city', baseTemp: 25, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 280 },
  
  // Northeast India
  { id: 'guwahati', name: 'Guwahati', region: 'Assam', country: 'India', type: 'city', baseTemp: 26, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 380 },
  { id: 'shillong', name: 'Shillong', region: 'Meghalaya', country: 'India', type: 'city', baseTemp: 18, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 500 },
  { id: 'imphal', name: 'Imphal', region: 'Manipur', country: 'India', type: 'city', baseTemp: 22, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 350 },
  { id: 'agartala', name: 'Agartala', region: 'Tripura', country: 'India', type: 'city', baseTemp: 25, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 380 },
  
  // Hill Stations
  { id: 'shimla', name: 'Shimla', region: 'Himachal Pradesh', country: 'India', type: 'city', baseTemp: 18, monsoonMonths: [7, 8, 9], monsoonIntensity: 280 },
  { id: 'manali', name: 'Manali', region: 'Himachal Pradesh', country: 'India', type: 'town', baseTemp: 15, monsoonMonths: [7, 8], monsoonIntensity: 250 },
  { id: 'srinagar', name: 'Srinagar', region: 'Jammu & Kashmir', country: 'India', type: 'city', baseTemp: 16, monsoonMonths: [3, 4], monsoonIntensity: 120 },
  { id: 'leh', name: 'Leh', region: 'Ladakh', country: 'India', type: 'town', baseTemp: 12, monsoonMonths: [7, 8], monsoonIntensity: 50 },
  { id: 'nainital', name: 'Nainital', region: 'Uttarakhand', country: 'India', type: 'town', baseTemp: 20, monsoonMonths: [7, 8, 9], monsoonIntensity: 350 },
  { id: 'mussoorie', name: 'Mussoorie', region: 'Uttarakhand', country: 'India', type: 'town', baseTemp: 19, monsoonMonths: [7, 8, 9], monsoonIntensity: 320 },
  
  // Villages & Small Towns
  { id: 'khimsar', name: 'Khimsar', region: 'Rajasthan', country: 'India', type: 'village', baseTemp: 28, monsoonMonths: [7, 8], monsoonIntensity: 90 },
  { id: 'hampi', name: 'Hampi', region: 'Karnataka', country: 'India', type: 'village', baseTemp: 28, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 140 },
  { id: 'alleppey', name: 'Alleppey', region: 'Kerala', country: 'India', type: 'town', baseTemp: 28, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 370 },
  { id: 'pondicherry', name: 'Pondicherry', region: 'Puducherry', country: 'India', type: 'city', baseTemp: 29, monsoonMonths: [10, 11], monsoonIntensity: 280 },
  { id: 'gokarna', name: 'Gokarna', region: 'Karnataka', country: 'India', type: 'town', baseTemp: 27, monsoonMonths: [6, 7, 8, 9], monsoonIntensity: 420 },
  { id: 'rishikesh', name: 'Rishikesh', region: 'Uttarakhand', country: 'India', type: 'town', baseTemp: 23, monsoonMonths: [7, 8, 9], monsoonIntensity: 300 },
];

// International Locations
export const internationalLocations: Location[] = [
  // USA
  { id: 'newyork', name: 'New York', region: 'New York', country: 'USA', type: 'city', baseTemp: 13, monsoonMonths: [4, 5, 6, 7], monsoonIntensity: 110 },
  { id: 'losangeles', name: 'Los Angeles', region: 'California', country: 'USA', type: 'city', baseTemp: 18, monsoonMonths: [1, 2, 3], monsoonIntensity: 60 },
  { id: 'chicago', name: 'Chicago', region: 'Illinois', country: 'USA', type: 'city', baseTemp: 11, monsoonMonths: [5, 6, 7], monsoonIntensity: 100 },
  
  // UK
  { id: 'london', name: 'London', region: 'England', country: 'UK', type: 'city', baseTemp: 11, monsoonMonths: [10, 11, 12], monsoonIntensity: 70 },
  { id: 'manchester', name: 'Manchester', region: 'England', country: 'UK', type: 'city', baseTemp: 10, monsoonMonths: [10, 11, 12], monsoonIntensity: 85 },
  
  // Australia
  { id: 'sydney', name: 'Sydney', region: 'New South Wales', country: 'Australia', type: 'city', baseTemp: 18, monsoonMonths: [1, 2, 3], monsoonIntensity: 120 },
  { id: 'melbourne', name: 'Melbourne', region: 'Victoria', country: 'Australia', type: 'city', baseTemp: 15, monsoonMonths: [10, 11, 12], monsoonIntensity: 60 },
  
  // Asia
  { id: 'tokyo', name: 'Tokyo', region: 'Kanto', country: 'Japan', type: 'city', baseTemp: 16, monsoonMonths: [6, 7, 9], monsoonIntensity: 150 },
  { id: 'singapore', name: 'Singapore', region: 'Singapore', country: 'Singapore', type: 'city', baseTemp: 27, monsoonMonths: [11, 12, 1], monsoonIntensity: 240 },
  { id: 'dubai', name: 'Dubai', region: 'Dubai', country: 'UAE', type: 'city', baseTemp: 28, monsoonMonths: [1, 2], monsoonIntensity: 20 },
  { id: 'bangkok', name: 'Bangkok', region: 'Central Thailand', country: 'Thailand', type: 'city', baseTemp: 29, monsoonMonths: [7, 8, 9, 10], monsoonIntensity: 160 },
  
  // Europe
  { id: 'paris', name: 'Paris', region: 'Île-de-France', country: 'France', type: 'city', baseTemp: 12, monsoonMonths: [5, 6], monsoonIntensity: 60 },
  { id: 'berlin', name: 'Berlin', region: 'Berlin', country: 'Germany', type: 'city', baseTemp: 10, monsoonMonths: [6, 7], monsoonIntensity: 60 },
  { id: 'rome', name: 'Rome', region: 'Lazio', country: 'Italy', type: 'city', baseTemp: 16, monsoonMonths: [10, 11], monsoonIntensity: 100 },
];

export const allLocations = [...indianLocations, ...internationalLocations];

export const countries = ['India', 'USA', 'UK', 'Australia', 'Japan', 'Singapore', 'UAE', 'Thailand', 'France', 'Germany', 'Italy'];
