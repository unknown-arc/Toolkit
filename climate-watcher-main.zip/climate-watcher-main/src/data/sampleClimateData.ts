// Sample climate data for demonstration
export interface ClimateDataPoint {
  date: string;
  temperature: number;
  rainfall: number;
  aqi: number;
  aqiCategory: string;
  year: number;
  month: number;
}

// AQI category helper
const getAQICategory = (aqi: number): string => {
  if (aqi <= 50) return "Good";
  if (aqi <= 100) return "Moderate";
  if (aqi <= 150) return "Unhealthy for Sensitive Groups";
  if (aqi <= 200) return "Unhealthy";
  if (aqi <= 300) return "Very Unhealthy";
  return "Hazardous";
};

// Generate sample data for any location (2014-2024)
export const generateSampleData = (location: { baseTemp: number; monsoonMonths: number[]; monsoonIntensity: number }): ClimateDataPoint[] => {
  const data: ClimateDataPoint[] = [];
  const startYear = 2014;
  const endYear = 2024;
  
  for (let year = startYear; year <= endYear; year++) {
    for (let month = 1; month <= 12; month++) {
      // Temperature patterns (in Celsius)
      const seasonalVariation = Math.sin((month - 3) * Math.PI / 6) * 4;
      const yearlyIncrease = (year - startYear) * 0.15; // Climate change trend
      const randomVariation = (Math.random() - 0.5) * 2;
      const temperature = location.baseTemp + seasonalVariation + yearlyIncrease + randomVariation;
      
      // Rainfall patterns (in mm)
      let rainfall = 0;
      if (location.monsoonMonths.includes(month)) {
        // Monsoon season
        const monsoonStart = location.monsoonMonths[0];
        const monsoonLength = location.monsoonMonths.length;
        const monthIndex = location.monsoonMonths.indexOf(month);
        const monsoonPeak = Math.sin(monthIndex * Math.PI / (monsoonLength - 1));
        rainfall = location.monsoonIntensity * monsoonPeak + Math.random() * 100;
      } else {
        // Dry season
        rainfall = Math.random() * 20;
      }
      
      // Slight decrease in monsoon rainfall over years (climate impact)
      if (location.monsoonMonths.includes(month)) {
        rainfall *= (1 - (year - startYear) * 0.01);
      }
      
      // AQI patterns (Air Quality Index: 0-500 scale)
      // AQI tends to be worse in winter months (Nov-Feb) and better during monsoon
      const baseAQI = 80; // Base level for typical urban area
      const seasonalAQI = location.monsoonMonths.includes(month) ? -30 : 20; // Better during monsoon
      const winterPenalty = [11, 12, 1, 2].includes(month) ? 40 : 0; // Worse in winter
      const aqiYearlyIncrease = (year - startYear) * 3; // Gradual worsening over time
      const randomAQI = (Math.random() - 0.5) * 30;
      const aqi = Math.max(0, Math.min(500, baseAQI + seasonalAQI + winterPenalty + aqiYearlyIncrease + randomAQI));
      
      const date = `${year}-${String(month).padStart(2, '0')}-01`;
      
      data.push({
        date,
        temperature: Math.round(temperature * 10) / 10,
        rainfall: Math.round(rainfall * 10) / 10,
        aqi: Math.round(aqi),
        aqiCategory: getAQICategory(Math.round(aqi)),
        year,
        month,
      });
    }
  }
  
  return data;
};

// Calculate moving average
export const calculateMovingAverage = (
  data: number[],
  windowSize: number = 12
): number[] => {
  const result: number[] = [];
  
  for (let i = 0; i < data.length; i++) {
    if (i < windowSize - 1) {
      result.push(NaN);
    } else {
      const window = data.slice(i - windowSize + 1, i + 1);
      const avg = window.reduce((sum, val) => sum + val, 0) / windowSize;
      result.push(Math.round(avg * 10) / 10);
    }
  }
  
  return result;
};

// Calculate statistics
export const calculateStats = (data: ClimateDataPoint[]) => {
  const temperatures = data.map(d => d.temperature);
  const rainfalls = data.map(d => d.rainfall);
  const aqis = data.map(d => d.aqi);
  
  const avgTemp = temperatures.reduce((a, b) => a + b, 0) / temperatures.length;
  const totalRainfall = rainfalls.reduce((a, b) => a + b, 0);
  const maxTemp = Math.max(...temperatures);
  const minTemp = Math.min(...temperatures);
  const avgAQI = aqis.reduce((a, b) => a + b, 0) / aqis.length;
  const maxAQI = Math.max(...aqis);
  const minAQI = Math.min(...aqis);
  
  // Calculate trend (last 5 years vs first 5 years)
  const firstFiveYearsTemp = temperatures.slice(0, 60).reduce((a, b) => a + b, 0) / 60;
  const lastFiveYearsTemp = temperatures.slice(-60).reduce((a, b) => a + b, 0) / 60;
  const tempTrend = lastFiveYearsTemp - firstFiveYearsTemp;
  
  const firstFiveYearsRain = rainfalls.slice(0, 60).reduce((a, b) => a + b, 0);
  const lastFiveYearsRain = rainfalls.slice(-60).reduce((a, b) => a + b, 0);
  const rainTrend = ((lastFiveYearsRain - firstFiveYearsRain) / firstFiveYearsRain) * 100;
  
  const firstFiveYearsAQI = aqis.slice(0, 60).reduce((a, b) => a + b, 0) / 60;
  const lastFiveYearsAQI = aqis.slice(-60).reduce((a, b) => a + b, 0) / 60;
  const aqiTrend = lastFiveYearsAQI - firstFiveYearsAQI;
  
  // Get current AQI (latest data point)
  const currentAQI = aqis[aqis.length - 1];
  const currentAQICategory = getAQICategory(currentAQI);
  
  return {
    avgTemp: Math.round(avgTemp * 10) / 10,
    totalRainfall: Math.round(totalRainfall),
    maxTemp: Math.round(maxTemp * 10) / 10,
    minTemp: Math.round(minTemp * 10) / 10,
    tempTrend: Math.round(tempTrend * 100) / 100,
    rainTrend: Math.round(rainTrend * 10) / 10,
    avgAQI: Math.round(avgAQI),
    maxAQI: Math.round(maxAQI),
    minAQI: Math.round(minAQI),
    aqiTrend: Math.round(aqiTrend),
    currentAQI: Math.round(currentAQI),
    currentAQICategory,
  };
};
