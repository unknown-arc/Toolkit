import { useState } from "react";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { allLocations, countries, Location } from "@/data/locationDatabase";
import { MapPin, ChevronsUpDown, Check, Plus, Globe } from "lucide-react";
import { cn } from "@/lib/utils";

interface LocationSelectorProps {
  selectedLocation: Location;
  onLocationChange: (location: Location) => void;
}

export const LocationSelector = ({ selectedLocation, onLocationChange }: LocationSelectorProps) => {
  const [open, setOpen] = useState(false);
  const [customDialogOpen, setCustomDialogOpen] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState<string>("All Countries");
  const [customLocation, setCustomLocation] = useState({
    name: '',
    region: '',
    country: 'India',
  });
  
  const filteredLocations = selectedCountry === "All Countries" 
    ? allLocations 
    : allLocations.filter(loc => loc.country === selectedCountry);

  // Group locations by state/region
  const locationsByRegion = filteredLocations.reduce((acc, loc) => {
    if (!acc[loc.region]) {
      acc[loc.region] = [];
    }
    acc[loc.region].push(loc);
    return acc;
  }, {} as Record<string, Location[]>);

  const sortedRegions = Object.keys(locationsByRegion).sort();

  const handleCustomLocationSubmit = () => {
    if (customLocation.name && customLocation.region) {
      const newLocation: Location = {
        id: `custom-${Date.now()}`,
        name: customLocation.name,
        region: customLocation.region,
        country: customLocation.country,
        type: 'city',
        baseTemp: 25,
        monsoonMonths: [6, 7, 8, 9],
        monsoonIntensity: 200,
      };
      onLocationChange(newLocation);
      setCustomDialogOpen(false);
      setCustomLocation({ name: '', region: '', country: 'India' });
    }
  };
  
  return (
    <>
      <div className="flex items-center gap-2 flex-wrap">
        <MapPin className="h-4 w-4 text-muted-foreground hidden sm:block" />
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              role="combobox"
              aria-expanded={open}
              className="w-full sm:w-[280px] justify-between bg-card hover:bg-secondary"
            >
              <span className="font-medium truncate">
                {selectedLocation.name}, {selectedLocation.region}
              </span>
              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-[350px] p-0 bg-card border-border z-50" align="end">
            <Command className="bg-card">
              <div className="flex items-center gap-2 p-2 border-b border-border">
                <Globe className="h-4 w-4 text-muted-foreground ml-2" />
                <Select value={selectedCountry} onValueChange={setSelectedCountry}>
                  <SelectTrigger className="h-8 text-xs border-0 focus:ring-0 bg-transparent">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card">
                    <SelectItem value="All Countries">All Countries</SelectItem>
                    {countries.map(country => (
                      <SelectItem key={country} value={country}>{country}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <CommandInput 
                placeholder="Search cities, towns, villages..." 
                className="h-9 bg-card"
              />
              <CommandList>
                <CommandEmpty className="py-6 text-center text-sm text-muted-foreground">
                  <p>No location found.</p>
                  <Button
                    variant="link"
                    size="sm"
                    onClick={() => {
                      setOpen(false);
                      setCustomDialogOpen(true);
                    }}
                    className="mt-2 text-primary"
                  >
                    <Plus className="h-3 w-3 mr-1" />
                    Add custom location
                  </Button>
                </CommandEmpty>
                <div className="max-h-[320px] overflow-auto">
                  <CommandGroup className="border-b border-border mb-2 pb-2">
                    <CommandItem
                      onSelect={() => {
                        setOpen(false);
                        setCustomDialogOpen(true);
                      }}
                      className="cursor-pointer"
                    >
                      <Plus className="mr-2 h-4 w-4 text-primary" />
                      <div className="flex flex-col">
                        <span className="font-medium text-primary">Add Custom Location</span>
                        <span className="text-xs text-muted-foreground">Add any city or village worldwide</span>
                      </div>
                    </CommandItem>
                  </CommandGroup>
                  
                  {sortedRegions.map((region) => (
                    <CommandGroup key={region} heading={region} className="mb-2">
                      {locationsByRegion[region].map((location) => (
                        <CommandItem
                          key={location.id}
                          value={`${location.name} ${location.region} ${location.country}`}
                          onSelect={() => {
                            onLocationChange(location);
                            setOpen(false);
                          }}
                          className="cursor-pointer"
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              selectedLocation.id === location.id ? "opacity-100" : "opacity-0"
                            )}
                          />
                          <div className="flex flex-col flex-1">
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{location.name}</span>
                              <span className="text-xs px-1.5 py-0.5 rounded-full bg-secondary text-muted-foreground">
                                {location.type}
                              </span>
                            </div>
                          </div>
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  ))}
                </div>
              </CommandList>
            </Command>
          </PopoverContent>
        </Popover>
      </div>

      {/* Custom Location Dialog */}
      <Dialog open={customDialogOpen} onOpenChange={setCustomDialogOpen}>
        <DialogContent className="sm:max-w-[425px] bg-card">
          <DialogHeader>
            <DialogTitle>Add Custom Location</DialogTitle>
            <DialogDescription>
              Add any city, town, or village from anywhere in the world to analyze its climate data.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="location-name">Location Name</Label>
              <Input
                id="location-name"
                placeholder="e.g., Rajgarh, Springfield"
                value={customLocation.name}
                onChange={(e) => setCustomLocation({ ...customLocation, name: e.target.value })}
                className="bg-background"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="region">State/Province/Region</Label>
              <Input
                id="region"
                placeholder="e.g., Madhya Pradesh, California"
                value={customLocation.region}
                onChange={(e) => setCustomLocation({ ...customLocation, region: e.target.value })}
                className="bg-background"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="country">Country</Label>
              <Select value={customLocation.country} onValueChange={(value) => setCustomLocation({ ...customLocation, country: value })}>
                <SelectTrigger className="bg-background">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-card">
                  {countries.map(country => (
                    <SelectItem key={country} value={country}>{country}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCustomDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCustomLocationSubmit} disabled={!customLocation.name || !customLocation.region}>
              Add Location
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};
