import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { ClimateDataPoint } from "@/data/sampleClimateData";

interface RainfallChartProps {
  data: ClimateDataPoint[];
}

export const RainfallChart = ({ data }: RainfallChartProps) => {
  // Group by year and sum rainfall
  const yearlyData = data.reduce((acc, point) => {
    const existing = acc.find(item => item.year === point.year);
    if (existing) {
      existing.rainfall += point.rainfall;
    } else {
      acc.push({ year: point.year, rainfall: point.rainfall });
    }
    return acc;
  }, [] as { year: number; rainfall: number }[]);

  const chartData = yearlyData.map(item => ({
    year: item.year.toString(),
    rainfall: Math.round(item.rainfall),
  }));

  return (
    <Card className="shadow-medium">
      <CardHeader>
        <CardTitle>Annual Rainfall</CardTitle>
        <CardDescription>Total rainfall by year (mm)</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={350}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis 
              dataKey="year" 
              stroke="hsl(var(--muted-foreground))"
              tick={{ fontSize: 12 }}
            />
            <YAxis 
              stroke="hsl(var(--muted-foreground))"
              tick={{ fontSize: 12 }}
              label={{ value: 'mm', angle: -90, position: 'insideLeft' }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "var(--radius)",
              }}
            />
            <Legend />
            <Bar
              dataKey="rainfall"
              fill="hsl(var(--chart-3))"
              name="Rainfall (mm)"
              radius={[8, 8, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};
