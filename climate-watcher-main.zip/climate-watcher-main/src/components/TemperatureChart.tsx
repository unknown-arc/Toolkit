import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { ClimateDataPoint } from "@/data/sampleClimateData";

interface TemperatureChartProps {
  data: ClimateDataPoint[];
  movingAverage?: number[];
}

export const TemperatureChart = ({ data, movingAverage }: TemperatureChartProps) => {
  const chartData = data.map((point, index) => ({
    date: point.date,
    temperature: point.temperature,
    movingAvg: movingAverage ? movingAverage[index] : null,
  }));

  return (
    <Card className="shadow-medium">
      <CardHeader>
        <CardTitle>Temperature Trends</CardTitle>
        <CardDescription>Monthly temperature analysis with 12-month moving average</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={350}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis 
              dataKey="date" 
              stroke="hsl(var(--muted-foreground))"
              tick={{ fontSize: 12 }}
              tickFormatter={(value) => {
                const date = new Date(value);
                return `${date.getFullYear()}`;
              }}
              interval={11}
            />
            <YAxis 
              stroke="hsl(var(--muted-foreground))"
              tick={{ fontSize: 12 }}
              label={{ value: '°C', angle: -90, position: 'insideLeft' }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "var(--radius)",
              }}
              labelFormatter={(value) => {
                const date = new Date(value);
                return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long' });
              }}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="temperature"
              stroke="hsl(var(--chart-2))"
              strokeWidth={1.5}
              dot={false}
              name="Temperature (°C)"
            />
            {movingAverage && (
              <Line
                type="monotone"
                dataKey="movingAvg"
                stroke="hsl(var(--chart-1))"
                strokeWidth={2.5}
                dot={false}
                name="12-Month Avg"
              />
            )}
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};
