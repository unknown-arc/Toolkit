import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { ClimateDataPoint } from "@/data/sampleClimateData";

interface MonthlyComparisonChartProps {
  data: ClimateDataPoint[];
}

export const MonthlyComparisonChart = ({ data }: MonthlyComparisonChartProps) => {
  // Compare average temperature by month across all years
  const monthlyAverages = Array.from({ length: 12 }, (_, i) => {
    const monthData = data.filter(d => d.month === i + 1);
    const avgTemp = monthData.reduce((sum, d) => sum + d.temperature, 0) / monthData.length;
    const avgRain = monthData.reduce((sum, d) => sum + d.rainfall, 0) / monthData.length;
    
    return {
      month: new Date(2024, i, 1).toLocaleDateString('en-US', { month: 'short' }),
      temperature: Math.round(avgTemp * 10) / 10,
      rainfall: Math.round(avgRain),
    };
  });

  return (
    <Card className="shadow-medium">
      <CardHeader>
        <CardTitle>Seasonal Patterns</CardTitle>
        <CardDescription>Average temperature and rainfall by month (2014-2024)</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={350}>
          <LineChart data={monthlyAverages}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis 
              dataKey="month" 
              stroke="hsl(var(--muted-foreground))"
              tick={{ fontSize: 12 }}
            />
            <YAxis 
              yAxisId="left"
              stroke="hsl(var(--chart-2))"
              tick={{ fontSize: 12 }}
              label={{ value: '°C', angle: -90, position: 'insideLeft' }}
            />
            <YAxis 
              yAxisId="right"
              orientation="right"
              stroke="hsl(var(--chart-3))"
              tick={{ fontSize: 12 }}
              label={{ value: 'mm', angle: 90, position: 'insideRight' }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "var(--radius)",
              }}
            />
            <Legend />
            <Line
              yAxisId="left"
              type="monotone"
              dataKey="temperature"
              stroke="hsl(var(--chart-2))"
              strokeWidth={2.5}
              dot={{ r: 4 }}
              name="Avg Temperature (°C)"
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="rainfall"
              stroke="hsl(var(--chart-3))"
              strokeWidth={2.5}
              dot={{ r: 4 }}
              name="Avg Rainfall (mm)"
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};
