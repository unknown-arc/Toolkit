import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Wind } from "lucide-react";

interface AQIGaugeProps {
  currentAQI: number;
  category: string;
}

export const AQIGauge = ({ currentAQI, category }: AQIGaugeProps) => {
  const getAQIColor = (aqi: number) => {
    if (aqi <= 50) return { bg: "bg-green-500", text: "text-green-500", border: "border-green-500" };
    if (aqi <= 100) return { bg: "bg-yellow-500", text: "text-yellow-500", border: "border-yellow-500" };
    if (aqi <= 150) return { bg: "bg-orange-400", text: "text-orange-400", border: "border-orange-400" };
    if (aqi <= 200) return { bg: "bg-orange-600", text: "text-orange-600", border: "border-orange-600" };
    if (aqi <= 300) return { bg: "bg-red-600", text: "text-red-600", border: "border-red-600" };
    return { bg: "bg-purple-700", text: "text-purple-700", border: "border-purple-700" };
  };

  const getHealthMessage = (aqi: number) => {
    if (aqi <= 50) return "Air quality is satisfactory, and air pollution poses little or no risk.";
    if (aqi <= 100) return "Air quality is acceptable. However, there may be a risk for some people, particularly those who are unusually sensitive to air pollution.";
    if (aqi <= 150) return "Members of sensitive groups may experience health effects. The general public is less likely to be affected.";
    if (aqi <= 200) return "Some members of the general public may experience health effects; members of sensitive groups may experience more serious health effects.";
    if (aqi <= 300) return "Health alert: The risk of health effects is increased for everyone.";
    return "Health warning of emergency conditions: everyone is more likely to be affected.";
  };

  const colors = getAQIColor(currentAQI);
  const percentage = Math.min((currentAQI / 500) * 100, 100);

  return (
    <Card className="shadow-soft">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Wind className="h-5 w-5" />
              Current Air Quality
            </CardTitle>
            <CardDescription>Live AQI reading for selected location</CardDescription>
          </div>
          <div className={`px-3 py-1 rounded-full ${colors.bg} text-white text-xs font-semibold`}>
            LIVE
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* AQI Value Display */}
          <div className="flex items-center justify-center">
            <div className={`relative w-40 h-40 rounded-full border-8 ${colors.border} flex items-center justify-center`}>
              <div className="text-center">
                <div className={`text-5xl font-bold ${colors.text}`}>{currentAQI}</div>
                <div className="text-sm text-muted-foreground mt-1">AQI</div>
              </div>
            </div>
          </div>

          {/* Category Badge */}
          <div className="text-center">
            <div className={`inline-block px-4 py-2 rounded-lg ${colors.bg} text-white font-semibold`}>
              {category}
            </div>
          </div>

          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>0</span>
              <span>Good</span>
              <span>Moderate</span>
              <span>Unhealthy</span>
              <span>500</span>
            </div>
            <div className="w-full h-3 bg-secondary rounded-full overflow-hidden">
              <div 
                className={`h-full ${colors.bg} transition-all duration-500`}
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>

          {/* Health Message */}
          <div className="bg-secondary rounded-lg p-4">
            <p className="text-sm text-muted-foreground leading-relaxed">
              {getHealthMessage(currentAQI)}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
