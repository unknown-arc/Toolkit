import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from "recharts";
import { ClimateDataPoint } from "@/data/sampleClimateData";

interface AQIChartProps {
  data: ClimateDataPoint[];
}

export const AQIChart = ({ data }: AQIChartProps) => {
  const chartData = data.map(d => ({
    date: d.date,
    aqi: d.aqi,
    year: d.year,
    month: d.month,
  }));

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const aqi = payload[0].value;
      let category = "Good";
      let color = "#10b981";
      
      if (aqi > 300) {
        category = "Hazardous";
        color = "#7e22ce";
      } else if (aqi > 200) {
        category = "Very Unhealthy";
        color = "#dc2626";
      } else if (aqi > 150) {
        category = "Unhealthy";
        color = "#ea580c";
      } else if (aqi > 100) {
        category = "Unhealthy for Sensitive Groups";
        color = "#f59e0b";
      } else if (aqi > 50) {
        category = "Moderate";
        color = "#eab308";
      }

      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
          <p className="text-sm font-semibold">{payload[0].payload.date}</p>
          <p className="text-sm" style={{ color }}>
            AQI: {aqi} - {category}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="shadow-soft">
      <CardHeader>
        <CardTitle>Air Quality Index (AQI) Trend</CardTitle>
        <CardDescription>
          Historical air quality data showing pollution levels over time (0-500 scale)
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis 
              dataKey="date" 
              tickFormatter={(value) => {
                const date = new Date(value);
                return date.getFullYear().toString();
              }}
              className="text-xs"
            />
            <YAxis 
              domain={[0, 500]}
              label={{ value: 'AQI', angle: -90, position: 'insideLeft' }}
              className="text-xs"
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            
            {/* AQI threshold lines */}
            <ReferenceLine y={50} stroke="#10b981" strokeDasharray="3 3" label={{ value: "Good", position: "right", fill: "#10b981", fontSize: 10 }} />
            <ReferenceLine y={100} stroke="#eab308" strokeDasharray="3 3" label={{ value: "Moderate", position: "right", fill: "#eab308", fontSize: 10 }} />
            <ReferenceLine y={150} stroke="#f59e0b" strokeDasharray="3 3" label={{ value: "Unhealthy (Sensitive)", position: "right", fill: "#f59e0b", fontSize: 10 }} />
            <ReferenceLine y={200} stroke="#ea580c" strokeDasharray="3 3" label={{ value: "Unhealthy", position: "right", fill: "#ea580c", fontSize: 10 }} />
            <ReferenceLine y={300} stroke="#dc2626" strokeDasharray="3 3" label={{ value: "Very Unhealthy", position: "right", fill: "#dc2626", fontSize: 10 }} />
            
            <Line 
              type="monotone" 
              dataKey="aqi" 
              stroke="hsl(var(--chart-3))" 
              strokeWidth={2}
              dot={false}
              name="Air Quality Index"
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};
