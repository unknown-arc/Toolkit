import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string | number;
  description?: string;
  trend?: number;
  trendLabel?: string;
  icon?: React.ReactNode;
  invertTrend?: boolean; // For metrics where higher = worse (e.g., AQI)
}

export const StatsCard = ({ title, value, description, trend, trendLabel, icon, invertTrend = false }: StatsCardProps) => {
  const isPositive = trend !== undefined && trend > 0;
  const isNegative = trend !== undefined && trend < 0;
  
  // For inverted metrics (like AQI), positive trend is bad, negative is good
  const isGoodTrend = invertTrend ? isNegative : isPositive;
  const isBadTrend = invertTrend ? isPositive : isNegative;
  
  return (
    <Card className="shadow-soft hover:shadow-medium transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
          {icon && <div className="text-muted-foreground">{icon}</div>}
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold text-foreground">{value}</div>
        {description && (
          <CardDescription className="mt-1">{description}</CardDescription>
        )}
        {trend !== undefined && (
          <div className="mt-2 flex items-center gap-1 text-sm">
            {isPositive && <TrendingUp className={`h-4 w-4 ${isGoodTrend ? "text-green-500" : "text-destructive"}`} />}
            {isNegative && <TrendingDown className={`h-4 w-4 ${isBadTrend ? "text-destructive" : "text-green-500"}`} />}
            <span className={isGoodTrend ? "text-green-500" : isBadTrend ? "text-destructive" : "text-muted-foreground"}>
              {trend > 0 ? "+" : ""}{trend}
            </span>
            {trendLabel && <span className="text-muted-foreground">{trendLabel}</span>}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
